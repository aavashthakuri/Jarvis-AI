package com.example.jarvis

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Real Android actions. Returns a result string if the text was a recognised command, else null (-> AI). English phrasing only. */
class Actions(private val ctx: Context) {

    fun tryHandle(raw: String): String? {
        val t = raw.trim().lowercase(Locale.ROOT)
            .replace(Regex("^(hey |ok )?jarvis[,.]?\\s*"), "").trimEnd('.', '!', '?').trim()

        if (Regex("\\b(what|tell|current|show)\\b.*\\b(time|date)\\b").containsMatchIn(t) && t.length < 40) {
            return "It's " + SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date()) + "."
        }
        if (Regex("\\b(flashlight|torch)\\b").containsMatchIn(t) &&
            Regex("\\b(turn|switch|toggle|enable|disable|on|off)\\b").containsMatchIn(t)) {
            return torch(!Regex("\\b(off|disable)\\b").containsMatchIn(t))
        }
        if (Regex("^open (the )?(android )?settings( app)?$").matches(t)) {
            return start(Intent(Settings.ACTION_SETTINGS), "Opening Settings.")
        }
        Regex("^(?:search|find) (?:on )?youtube (?:for )?(.+)$").find(t)?.let {
            val q = it.groupValues[1]
            return start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))),
                "Searching YouTube for $q.")
        }
        if ("whatsapp" in t && Regex("\\b(send|message|text)\\b").containsMatchIn(t)) {
            Regex("whatsapp.*?(\\+?[0-9][0-9 ]{7,16}[0-9])\\s*(?:saying|that|:)?\\s*(.*)$").find(t)?.let {
                val num = it.groupValues[1].filter { c -> c.isDigit() }
                val msg = it.groupValues[2]
                return start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=" + Uri.encode(msg))),
                    "WhatsApp chat opened with your message filled in. Android requires you to tap Send yourself.")
            }
            return openApp("WhatsApp") + " I can't pick contacts or press Send yet. Say: WhatsApp +977XXXXXXXXXX saying hello."
        }
        Regex("^(?:open|launch|start) (.+)$").find(t)?.let { return openApp(it.groupValues[1]) }
        return null
    }

    private fun start(i: Intent, ok: String): String = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); ok
    } catch (e: Exception) { "Android wouldn't let me do that: ${e.message}" }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val n = name.trim()
        val hit = apps.firstOrNull { it.first.equals(n, true) } ?: apps.firstOrNull { it.first.contains(n, true) }
            ?: return "I couldn't find an installed app called \"$n\"."
        val i = pm.getLaunchIntentForPackage(hit.second) ?: return "${hit.first} has no launchable screen."
        return start(i, "Opening ${hit.first}.")
    }

    private fun torch(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "This phone doesn't report a flashlight."
            cm.setTorchMode(id, on)
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) { "I couldn't switch the flashlight: ${e.message}" }
    }
}
