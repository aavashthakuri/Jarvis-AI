package com.example.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Msg(val role: String, val text: String)

/** Local persistence. Private app storage; corrupted files are ignored, never crash. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val histFile = File(ctx.filesDir, "history.json")
    private val memFile = File(ctx.filesDir, "memories.json")

    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) { prefs.edit().putString("key", v.trim()).apply() }
    var model: String
        get() = prefs.getString("model", "gemini-2.0-flash") ?: "gemini-2.0-flash"
        set(v) { prefs.edit().putString("model", v.trim()).apply() }
    var lang: String
        get() = prefs.getString("lang", "en-US") ?: "en-US"
        set(v) { prefs.edit().putString("lang", v).apply() }
    var speak: Boolean
        get() = prefs.getBoolean("speak", true)
        set(v) { prefs.edit().putBoolean("speak", v).apply() }

    fun loadHistory(): List<Msg> = try {
        val a = JSONArray(histFile.readText())
        (0 until a.length()).map { val o = a.getJSONObject(it); Msg(o.getString("r"), o.getString("t")) }
    } catch (e: Exception) { emptyList() }

    fun saveHistory(l: List<Msg>) {
        try {
            val a = JSONArray()
            l.takeLast(200).forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }
            histFile.writeText(a.toString())
        } catch (e: Exception) { }
    }

    fun memories(): List<String> = try {
        val a = JSONArray(memFile.readText()); (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }

    fun saveMemories(l: List<String>) {
        try { memFile.writeText(JSONArray(l).toString()) } catch (e: Exception) { }
    }
}
