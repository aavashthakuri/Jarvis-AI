package com.example.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

private val Cyan = Color(0xFF00E5FF)
private val Bg = Color(0xFF020B14)
private val Panel = Color(0xFF0A1B2A)

class MainActivity : ComponentActivity() {
    private val vm: JarvisVM by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
                JarvisScreen(vm)
            }
        }
    }
}

@Composable
fun JarvisScreen(vm: JarvisVM) {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.listen() else vm.notice = "Microphone permission denied. Voice input needs it; text input still works."
    }
    fun mic() {
        when {
            vm.state == St.LISTENING -> vm.cancelListen()
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> vm.listen()
            else -> perm.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    val list = rememberLazyListState()
    LaunchedEffect(vm.msgs.size) { if (vm.msgs.isNotEmpty()) list.animateScrollToItem(vm.msgs.size - 1) }

    Column(Modifier.fillMaxSize().background(Bg).padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("J.A.R.V.I.S", color = Cyan, fontSize = 20.sp, letterSpacing = 4.sp, modifier = Modifier.weight(1f))
            Text("⚙", fontSize = 24.sp, color = Cyan, modifier = Modifier.clickable { showSettings = true }.padding(8.dp))
        }
        Reactor(vm.state, vm.level, Modifier.fillMaxWidth().height(190.dp))
        Text(
            if (vm.partial.isNotEmpty()) vm.partial else vm.state.label,
            color = Cyan.copy(alpha = 0.85f), fontSize = 13.sp, letterSpacing = 3.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Waves(vm.state, vm.level, Modifier.fillMaxWidth().height(44.dp).padding(vertical = 4.dp))
        vm.notice?.let {
            Text(it, color = Color(0xFFFFB74D), fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth().clickable { vm.notice = null }.padding(4.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.msgs.toList()) { m ->
                val user = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
                    Text(
                        m.text, color = Color.White, fontSize = 15.sp,
                        modifier = Modifier.widthIn(max = 300.dp)
                            .border(1.dp, if (user) Color(0xFF2979FF) else Cyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                            .background(if (user) Color(0xFF0D2A55) else Panel, RoundedCornerShape(14.dp))
                            .padding(10.dp)
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type to JARVIS…") }, singleLine = true
            )
            Text("➤", color = Cyan, fontSize = 26.sp, modifier = Modifier.clickable {
                if (input.isNotBlank()) { vm.send(input); input = "" }
            }.padding(10.dp))
            Box(
                Modifier.size(56.dp).clip(CircleShape).background(if (vm.state == St.LISTENING) Cyan else Panel)
                    .border(2.dp, Cyan, CircleShape)
                    .clickable { if (vm.state == St.SPEAKING) vm.stopSpeaking().also { mic() } else mic() },
                contentAlignment = Alignment.Center
            ) { Text("🎤", fontSize = 24.sp) }
        }
    }
    if (showSettings) SettingsDialog(vm) { vm.saveSettings(); showSettings = false }
}

@Composable
fun Reactor(state: St, level: Float, modifier: Modifier) {
    val inf = rememberInfiniteTransition(label = "reactor")
    val rot by inf.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (state == St.IDLE) 14000 else 5000, easing = LinearEasing)), label = "rot"
    )
    val pulse by inf.animateFloat(
        initialValue = 0.8f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "pulse"
    )
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.4f * pulse), Color.Transparent), c, r), r)
        for (i in 1..3) drawCircle(Cyan.copy(alpha = 0.3f), r * (0.3f + 0.22f * i), c, style = Stroke(2f))
        for (k in 0 until 3) {
            val rr = r * (0.55f + 0.17f * k)
            drawArc(
                Cyan.copy(alpha = 0.9f), rot * (if (k % 2 == 0) 1f else -1f) + k * 120f, 70f, false,
                Offset(c.x - rr, c.y - rr), Size(rr * 2, rr * 2), style = Stroke(6f, cap = StrokeCap.Round)
            )
        }
        val core = r * 0.28f * (0.9f + 0.3f * level) * (if (state == St.IDLE) 0.9f else pulse + 0.1f)
        drawCircle(Brush.radialGradient(listOf(Color.White, Cyan, Color(0xFF0066FF)), c, core), core, c)
    }
}

@Composable
fun Waves(state: St, level: Float, modifier: Modifier) {
    val t by rememberInfiniteTransition(label = "w").animateFloat(
        initialValue = 0f, targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "t"
    )
    val amp = when (state) {
        St.LISTENING -> 0.25f + level * 0.75f
        St.SPEAKING -> 0.7f
        St.THINKING, St.ACTING -> 0.35f
        else -> 0.08f
    }
    Canvas(modifier) {
        val n = 33
        val w = size.width / n
        for (i in 0 until n) {
            val env = sin(Math.PI.toFloat() * i / (n - 1))
            val h = max(size.height * amp * env * (0.3f + 0.7f * abs(sin(t + i * 0.5f))), 4f)
            drawRoundRect(Cyan, Offset(i * w + w * 0.25f, (size.height - h) / 2), Size(w * 0.5f, h), CornerRadius(w / 4))
        }
    }
}

@Composable
fun SettingsDialog(vm: JarvisVM, onClose: () -> Unit) {
    val langs = listOf("English (US)" to "en-US", "English (IN)" to "en-IN", "हिन्दी" to "hi-IN", "नेपाली" to "ne-NP")
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClose) { Text("Save") } },
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.apiKey, { vm.apiKey = it }, label = { Text("Gemini API key (free, AI Studio)") },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(vm.model, { vm.model = it }, label = { Text("Gemini model name") }, singleLine = true)
                Text("Voice language", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    langs.forEach { (label, tag) ->
                        TextButton({ vm.lang = tag }) {
                            Text(label, color = if (vm.lang == tag) Cyan else Color.Gray)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Speak replies", Modifier.weight(1f)); Switch(vm.speakOn, { vm.speakOn = it })
                }
                Text("Saved memories (${vm.memories.size})", fontSize = 12.sp)
                vm.memories.forEach { Text("• $it", fontSize = 13.sp) }
                Row {
                    TextButton({ vm.clearHistory() }) { Text("Clear history") }
                    TextButton({ vm.clearMemories() }) { Text("Clear memories") }
                }
            }
        }
    )
}
