package com.example.jarvis

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class St(val label: String) {
    IDLE("STANDING BY"), LISTENING("LISTENING"), THINKING("THINKING"), ACTING("EXECUTING ACTION"), SPEAKING("SPEAKING")
}

class JarvisVM(private val app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    private val actions = Actions(app)
    val msgs = mutableStateListOf<Msg>().apply { addAll(store.loadHistory()) }
    var state by mutableStateOf(St.IDLE)
    var partial by mutableStateOf("")
    var level by mutableStateOf(0f)
    var notice by mutableStateOf<String?>(null)
    var lang by mutableStateOf(store.lang)
    var speakOn by mutableStateOf(store.speak)
    var apiKey by mutableStateOf(store.apiKey)
    var model by mutableStateOf(store.model)
    var memories by mutableStateOf(store.memories())

    private var tts: TextToSpeech? = null
    private var rec: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(app) { s ->
            if (s == TextToSpeech.SUCCESS) {
                applyLang(); tts?.setPitch(0.85f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { state = St.IDLE }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { state = St.IDLE }
                })
            } else notice = "Text-to-speech engine unavailable on this phone."
        }
    }

    private fun applyLang() {
        val r = tts?.setLanguage(Locale.forLanguageTag(lang))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            notice = "No $lang voice installed for speech output. Install one in Android settings > Text-to-speech."
    }

    fun saveSettings() {
        store.apiKey = apiKey; store.model = model; store.lang = lang; store.speak = speakOn; applyLang()
    }

    fun clearHistory() { msgs.clear(); store.saveHistory(emptyList()) }
    fun clearMemories() { store.saveMemories(emptyList()); memories = emptyList() }

    private fun add(m: Msg) { msgs.add(m); store.saveHistory(msgs.toList()) }

    fun listen() {
        tts?.stop()
        if (!SpeechRecognizer.isRecognitionAvailable(app)) { notice = "No speech recognition service on this phone (needs Google app)."; state = St.IDLE; return }
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(app).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { state = St.LISTENING; partial = "" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onPartialResults(b: Bundle?) {
                    partial = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                }
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    partial = ""; level = 0f
                    if (t.isNullOrBlank()) { state = St.IDLE; notice = "I didn't catch that." } else send(t)
                }
                override fun onError(e: Int) {
                    partial = ""; level = 0f; state = St.IDLE
                    notice = when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Try again."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs internet (or an offline language pack)."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission missing."
                        SpeechRecognizer.ERROR_CLIENT -> null
                        else -> "Speech recognition error ($e)."
                    }
                }
            })
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            )
        }
    }

    fun cancelListen() { rec?.cancel(); state = St.IDLE; partial = ""; level = 0f }
    fun stopSpeaking() { tts?.stop(); state = St.IDLE }

    fun send(text: String) {
        val t = text.trim(); if (t.isEmpty()) return
        tts?.stop(); notice = null
        add(Msg("user", t)); state = St.THINKING
        viewModelScope.launch {
            val mem = Regex("^(?:jarvis[, ]*)?remember (?:that )?(.+)", RegexOption.IGNORE_CASE).find(t)
            val reply = try {
                if (mem != null) {
                    memories = memories + mem.groupValues[1]; store.saveMemories(memories)
                    "Got it. I'll remember that."
                } else actions.tryHandle(t)?.also { state = St.ACTING } ?: ai()
            } catch (e: Exception) { "Sorry, ${e.message ?: "something went wrong"}." }
            add(Msg("assistant", reply)); speak(reply)
        }
    }

    private suspend fun ai(): String {
        if (store.apiKey.isBlank())
            return "I need a free Gemini API key to chat. Tap the gear icon and paste one from Google AI Studio. Phone commands still work without it."
        val now = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())
        val mem = if (memories.isEmpty()) "none" else memories.joinToString("; ")
        val sys = """You are JARVIS, a personal voice assistant on the user's Android phone. Be friendly, caring, logical and natural, with an occasional light joke. 
Reply in the language the user writes in (English, Nepali, Hindi, Romanized Nepali). Keep replies short (1-3 sentences) since they are spoken aloud, unless asked for detail. 
Respectfully disagree when the user's assumption is wrong. Separate facts from uncertainty and say when you don't know. You have NO web access, so say so for current events. 
You cannot perform phone actions yourself: never claim you opened, sent, or changed anything. Phone commands are handled separately by the app. 
Now: $now. Saved user memories: $mem. Do not use markdown."""
        return Ai.chat(store.apiKey, store.model, sys, msgs.toList())
    }

    private fun speak(text: String) {
        if (!speakOn) { state = St.IDLE; return }
        state = St.SPEAKING
        tts?.speak(text.replace(Regex("[*_`#]"), ""), TextToSpeech.QUEUE_FLUSH, null, "j")
    }

    override fun onCleared() { tts?.shutdown(); rec?.destroy() }
}
