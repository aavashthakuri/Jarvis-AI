package com.example.jarvis

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Google Gemini REST API (free tier via an AI Studio key, no credit card). Key is sent in a header and never logged. */
object Ai {
    suspend fun chat(key: String, model: String, system: String, history: List<Msg>): String =
        withContext(Dispatchers.IO) {
            val contents = JSONArray()
            history.takeLast(20).forEach {
                contents.put(
                    JSONObject().put("role", if (it.role == "user") "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
                )
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.connectTimeout = 15000; c.readTimeout = 40000; c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                if (code !in 200..299) throw Exception(
                    when (code) {
                        400 -> "the API rejected the request (check the API key and model name)"
                        403 -> "the API key was rejected"
                        404 -> "model name not found; change it in Settings"
                        429 -> "free-tier rate limit reached; wait a minute and retry"
                        else -> "AI service error $code"
                    }
                )
                try {
                    JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
                } catch (e: Exception) { throw Exception("the AI returned an empty or blocked response") }
            } finally { c.disconnect() }
        }
}
