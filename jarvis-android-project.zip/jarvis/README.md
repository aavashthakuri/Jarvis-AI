# JARVIS (v0.1) — native Android, Kotlin + Compose

STATUS: source has NOT been compiled or run by the author (no network/SDK in the authoring sandbox). Expect to fix small compile errors on first build.

## Easiest phone-only build: GitHub Actions (free)
1. Create a GitHub repo from your phone browser, upload this project (keep `.github/workflows/build.yml`).
2. Actions tab > "Build APK" > Run workflow. Download the `jarvis-debug-apk` artifact, unzip, install.

## Build in Termux (experimental; Android SDK on ARM is the fragile part)
```
pkg update && pkg install openjdk-17 gradle aapt2 wget unzip
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-*.zip && mv cmdline-tools latest
export ANDROID_HOME=$HOME/android-sdk
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0"
cd ~/jarvis   # project folder
echo "sdk.dir=$ANDROID_HOME" > local.properties
echo "android.aapt2FromMavenOverride=$PREFIX/bin/aapt2" >> gradle.properties
gradle wrapper --gradle-version 8.7
./gradlew assembleDebug --no-daemon
```
APK: app/build/outputs/apk/debug/app-debug.apk (`termux-open` it, or copy to /sdcard).
Troubleshooting: aapt2 "Syntax error/cannot execute" = override line missing. Out of memory = lower `org.jetbrains` Xmx in gradle.properties or close apps. "SDK location not found" = local.properties.

## AI key (free, no card)
Google AI Studio > Get API key > paste in app Settings (gear). Free tier has rate limits; limits/model names can change, edit the model name in Settings if you get a 404.
